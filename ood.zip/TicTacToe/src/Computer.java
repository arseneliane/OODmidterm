public class Computer extends Player {
    public Computer(char sign) {
        super("Computer", sign);
    }

    @Override
    public void playTurn(Grid grid) {
        String move = findBestMove(grid);
        grid.setCell(move, this.getSign());
        System.out.println("Computer played: " + move);
    }

    private String findBestMove(Grid grid) {
        int bestScore = Integer.MIN_VALUE;
        String bestMove = "";
        
        String[] positions = {"A1", "A2", "A3", "B1", "B2", "B3", "C1", "C2", "C3"};

        for (String move : positions) {
            if (grid.isValidMove(move)) {
                grid.setCell(move, this.getSign());
                int score = minimax(grid, false);
                grid.setCell(move, ' '); // Undo move
                
                if (score > bestScore) {
                    bestScore = score;
                    bestMove = move;
                }
            }
        }
        return bestMove;
    }

    private int minimax(Grid grid, boolean isMaximizing) {
        char winner = grid.checkWinner();
        if (winner == this.getSign()) return 10;
        if (winner != ' ' && winner != this.getSign()) return -10;
        if (grid.isBoardFull()) return 0;

        int bestScore = isMaximizing ? Integer.MIN_VALUE : Integer.MAX_VALUE;
        char currentPlayer = isMaximizing ? this.getSign() : (this.getSign() == 'X' ? 'O' : 'X');
        
        String[] positions = {"A1", "A2", "A3", "B1", "B2", "B3", "C1", "C2", "C3"};
        
        for (String move : positions) {
            if (grid.isValidMove(move)) {
                grid.setCell(move, currentPlayer);
                int score = minimax(grid, !isMaximizing);
                grid.setCell(move, ' '); // Undo move
                
                bestScore = isMaximizing ? Math.max(bestScore, score) : Math.min(bestScore, score);
            }
        }
        return bestScore;
    }
}

